import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const listCourses = query({
  args: {},
  handler: async (ctx) => {
    const courses = await ctx.db.query("courses").collect();
    const userId = await getAuthUserId(ctx);
    
    if (!userId) {
      return courses.map(course => ({
        ...course,
        progress: null,
        isCompleted: false,
      }));
    }

    // Get user progress for all courses
    const userProgress = await ctx.db
      .query("userProgress")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const progressMap = new Map(
      userProgress.map(p => [p.courseId, p])
    );

    return courses.map(course => {
      const progress = progressMap.get(course._id);
      return {
        ...course,
        progress: progress ? {
          completedLessons: progress.completedLessons.length,
          totalLessons: course.lessons.length,
          isCompleted: progress.isCompleted,
        } : null,
        isCompleted: progress?.isCompleted || false,
      };
    });
  },
});

export const getCourse = query({
  args: { courseId: v.id("courses") },
  handler: async (ctx, args) => {
    const course = await ctx.db.get(args.courseId);
    if (!course) return null;

    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return {
        ...course,
        userProgress: null,
      };
    }

    const userProgress = await ctx.db
      .query("userProgress")
      .withIndex("by_user_and_course", (q) => 
        q.eq("userId", userId).eq("courseId", args.courseId)
      )
      .unique();

    return {
      ...course,
      userProgress,
    };
  },
});

export const markCourseCompleted = mutation({
  args: { courseId: v.id("courses") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to mark course as completed");
    }

    const course = await ctx.db.get(args.courseId);
    if (!course) {
      throw new Error("Course not found");
    }

    const existingProgress = await ctx.db
      .query("userProgress")
      .withIndex("by_user_and_course", (q) => 
        q.eq("userId", userId).eq("courseId", args.courseId)
      )
      .unique();

    const allLessonIds = course.lessons.map(lesson => lesson.id);

    if (existingProgress) {
      await ctx.db.patch(existingProgress._id, {
        completedLessons: allLessonIds,
        isCompleted: true,
        completedAt: Date.now(),
      });
    } else {
      await ctx.db.insert("userProgress", {
        userId,
        courseId: args.courseId,
        completedLessons: allLessonIds,
        isCompleted: true,
        completedAt: Date.now(),
      });
    }
  },
});

export const toggleLessonCompleted = mutation({
  args: { 
    courseId: v.id("courses"),
    lessonId: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to track progress");
    }

    const course = await ctx.db.get(args.courseId);
    if (!course) {
      throw new Error("Course not found");
    }

    const existingProgress = await ctx.db
      .query("userProgress")
      .withIndex("by_user_and_course", (q) => 
        q.eq("userId", userId).eq("courseId", args.courseId)
      )
      .unique();

    let completedLessons: string[] = [];
    
    if (existingProgress) {
      completedLessons = existingProgress.completedLessons.includes(args.lessonId)
        ? existingProgress.completedLessons.filter(id => id !== args.lessonId)
        : [...existingProgress.completedLessons, args.lessonId];
    } else {
      completedLessons = [args.lessonId];
    }

    const isCompleted = completedLessons.length === course.lessons.length;

    if (existingProgress) {
      await ctx.db.patch(existingProgress._id, {
        completedLessons,
        isCompleted,
        completedAt: isCompleted ? Date.now() : undefined,
      });
    } else {
      await ctx.db.insert("userProgress", {
        userId,
        courseId: args.courseId,
        completedLessons,
        isCompleted,
        completedAt: isCompleted ? Date.now() : undefined,
      });
    }
  },
});

// Seed function to populate initial course data
export const seedCourses = mutation({
  args: {},
  handler: async (ctx) => {
    const existingCourses = await ctx.db.query("courses").collect();
    if (existingCourses.length > 0) {
      return "Courses already exist";
    }

    const sampleCourses = [
      {
        title: "Introduction to Web Development",
        description: "Learn the fundamentals of HTML, CSS, and JavaScript to build modern websites.",
        instructor: "Sarah Johnson",
        duration: "6 weeks",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=250&fit=crop",
        lessons: [
          { id: "1", title: "HTML Basics", duration: "45 min" },
          { id: "2", title: "CSS Fundamentals", duration: "60 min" },
          { id: "3", title: "JavaScript Introduction", duration: "75 min" },
          { id: "4", title: "Responsive Design", duration: "50 min" },
          { id: "5", title: "Building Your First Website", duration: "90 min" },
        ],
      },
      {
        title: "React for Beginners",
        description: "Master React.js and build interactive user interfaces with modern JavaScript.",
        instructor: "Mike Chen",
        duration: "8 weeks",
        level: "Intermediate",
        imageUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=250&fit=crop",
        lessons: [
          { id: "1", title: "React Components", duration: "55 min" },
          { id: "2", title: "State and Props", duration: "65 min" },
          { id: "3", title: "Event Handling", duration: "40 min" },
          { id: "4", title: "React Hooks", duration: "70 min" },
          { id: "5", title: "Building a Todo App", duration: "85 min" },
          { id: "6", title: "API Integration", duration: "60 min" },
        ],
      },
      {
        title: "Python Programming Essentials",
        description: "Learn Python from scratch and build real-world applications.",
        instructor: "Dr. Emily Rodriguez",
        duration: "10 weeks",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=400&h=250&fit=crop",
        lessons: [
          { id: "1", title: "Python Syntax", duration: "50 min" },
          { id: "2", title: "Data Types and Variables", duration: "45 min" },
          { id: "3", title: "Control Structures", duration: "60 min" },
          { id: "4", title: "Functions and Modules", duration: "55 min" },
          { id: "5", title: "Object-Oriented Programming", duration: "75 min" },
          { id: "6", title: "File Handling", duration: "40 min" },
          { id: "7", title: "Error Handling", duration: "35 min" },
          { id: "8", title: "Building a CLI App", duration: "80 min" },
        ],
      },
      {
        title: "Data Science with Python",
        description: "Analyze data and create visualizations using Python libraries like Pandas and Matplotlib.",
        instructor: "Alex Thompson",
        duration: "12 weeks",
        level: "Advanced",
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=250&fit=crop",
        lessons: [
          { id: "1", title: "NumPy Fundamentals", duration: "65 min" },
          { id: "2", title: "Pandas for Data Analysis", duration: "80 min" },
          { id: "3", title: "Data Visualization", duration: "70 min" },
          { id: "4", title: "Statistical Analysis", duration: "85 min" },
          { id: "5", title: "Machine Learning Basics", duration: "95 min" },
        ],
      },
    ];

    for (const course of sampleCourses) {
      await ctx.db.insert("courses", course);
    }

    return "Sample courses created successfully";
  },
});
