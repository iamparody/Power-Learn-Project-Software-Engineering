import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  courses: defineTable({
    title: v.string(),
    description: v.string(),
    instructor: v.string(),
    duration: v.string(),
    level: v.string(),
    imageUrl: v.string(),
    lessons: v.array(v.object({
      id: v.string(),
      title: v.string(),
      duration: v.string(),
      videoUrl: v.optional(v.string()),
    })),
  }),
  
  userProgress: defineTable({
    userId: v.id("users"),
    courseId: v.id("courses"),
    completedLessons: v.array(v.string()),
    isCompleted: v.boolean(),
    completedAt: v.optional(v.number()),
  }).index("by_user", ["userId"])
    .index("by_user_and_course", ["userId", "courseId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
