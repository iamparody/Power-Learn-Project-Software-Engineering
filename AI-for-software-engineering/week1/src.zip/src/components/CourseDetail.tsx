import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

interface CourseDetailProps {
  courseId: Id<"courses">;
  onBack: () => void;
}

export function CourseDetail({ courseId, onBack }: CourseDetailProps) {
  const course = useQuery(api.courses.getCourse, { courseId });
  const markCompleted = useMutation(api.courses.markCourseCompleted);
  const toggleLesson = useMutation(api.courses.toggleLessonCompleted);

  if (!course) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const completedLessons = course.userProgress?.completedLessons || [];
  const isCompleted = course.userProgress?.isCompleted || false;
  const progressPercentage = (completedLessons.length / course.lessons.length) * 100;

  const handleMarkCompleted = async () => {
    try {
      await markCompleted({ courseId });
      toast.success("Course marked as completed! 🎉");
    } catch (error) {
      toast.error("Failed to mark course as completed");
    }
  };

  const handleToggleLesson = async (lessonId: string) => {
    try {
      await toggleLesson({ courseId, lessonId });
      const isCurrentlyCompleted = completedLessons.includes(lessonId);
      toast.success(isCurrentlyCompleted ? "Lesson unmarked" : "Lesson completed! ✓");
    } catch (error) {
      toast.error("Failed to update lesson progress");
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Course Header */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <img
          src={course.imageUrl}
          alt={course.title}
          className="w-full h-64 object-cover"
        />
        <div className="p-8">
          <div className="flex items-center justify-between mb-4">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              course.level === 'Beginner' ? 'bg-green-100 text-green-800' :
              course.level === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
              'bg-red-100 text-red-800'
            }`}>
              {course.level}
            </span>
            {isCompleted && (
              <span className="text-green-600 font-medium flex items-center gap-2">
                ✓ Course Completed
              </span>
            )}
          </div>

          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            {course.title}
          </h1>

          <p className="text-gray-600 text-lg mb-6">
            {course.description}
          </p>

          <div className="flex items-center gap-8 text-gray-600 mb-6">
            <span className="flex items-center gap-2">
              👨‍🏫 {course.instructor}
            </span>
            <span className="flex items-center gap-2">
              ⏱️ {course.duration}
            </span>
            <span className="flex items-center gap-2">
              📚 {course.lessons.length} lessons
            </span>
          </div>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Course Progress</span>
              <span>{completedLessons.length}/{course.lessons.length} lessons completed</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className="bg-blue-600 h-3 rounded-full transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
            <div className="text-right text-sm text-gray-600 mt-1">
              {Math.round(progressPercentage)}% complete
            </div>
          </div>

          {/* Action Button */}
          {!isCompleted && (
            <button
              onClick={handleMarkCompleted}
              className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium"
            >
              Mark Course as Completed
            </button>
          )}
        </div>
      </div>

      {/* Lessons List */}
      <div className="bg-white rounded-lg shadow-md p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Course Lessons</h2>
        
        <div className="space-y-4">
          {course.lessons.map((lesson, index) => {
            const isLessonCompleted = completedLessons.includes(lesson.id);
            
            return (
              <div
                key={lesson.id}
                className={`p-4 rounded-lg border-2 transition-all duration-200 cursor-pointer hover:shadow-md ${
                  isLessonCompleted
                    ? 'border-green-200 bg-green-50'
                    : 'border-gray-200 bg-gray-50 hover:border-blue-200'
                }`}
                onClick={() => handleToggleLesson(lesson.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      isLessonCompleted
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-300 text-gray-600'
                    }`}>
                      {isLessonCompleted ? '✓' : index + 1}
                    </div>
                    <div>
                      <h3 className={`font-medium ${
                        isLessonCompleted ? 'text-green-800' : 'text-gray-900'
                      }`}>
                        {lesson.title}
                      </h3>
                      <p className="text-sm text-gray-600">
                        Duration: {lesson.duration}
                      </p>
                    </div>
                  </div>
                  
                  <button
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                      isLessonCompleted
                        ? 'bg-green-600 text-white hover:bg-green-700'
                        : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`}
                  >
                    {isLessonCompleted ? 'Completed' : 'Mark Complete'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
