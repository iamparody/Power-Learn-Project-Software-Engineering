import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { CourseList } from "./components/CourseList";
import { CourseDetail } from "./components/CourseDetail";
import { useState } from "react";
import { Id } from "../convex/_generated/dataModel";

export default function App() {
  const [selectedCourseId, setSelectedCourseId] = useState<Id<"courses"> | null>(null);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm h-16 flex justify-between items-center border-b shadow-sm px-4">
        <div className="flex items-center gap-4">
          <h2 
            className="text-xl font-semibold text-blue-600 cursor-pointer hover:text-blue-700 transition-colors"
            onClick={() => setSelectedCourseId(null)}
          >
            📚 EduPlatform
          </h2>
          {selectedCourseId && (
            <button
              onClick={() => setSelectedCourseId(null)}
              className="text-sm text-gray-600 hover:text-gray-800 transition-colors"
            >
              ← Back to Courses
            </button>
          )}
        </div>
        <SignOutButton />
      </header>
      <main className="flex-1 p-6">
        <Content 
          selectedCourseId={selectedCourseId}
          setSelectedCourseId={setSelectedCourseId}
        />
      </main>
      <Toaster />
    </div>
  );
}

function Content({ 
  selectedCourseId, 
  setSelectedCourseId 
}: { 
  selectedCourseId: Id<"courses"> | null;
  setSelectedCourseId: (id: Id<"courses"> | null) => void;
}) {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <Unauthenticated>
        <div className="text-center py-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome to EduPlatform
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Sign in to access our courses and track your progress
          </p>
          <div className="max-w-md mx-auto">
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>

      <Authenticated>
        {selectedCourseId ? (
          <CourseDetail 
            courseId={selectedCourseId}
            onBack={() => setSelectedCourseId(null)}
          />
        ) : (
          <CourseList onSelectCourse={setSelectedCourseId} />
        )}
      </Authenticated>
    </div>
  );
}
